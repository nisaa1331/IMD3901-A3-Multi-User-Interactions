Anisa Johnny
IMD3901A Design Studio 3
Assignment 3: Multi-User Interactions
March 7th, 2023

Overview of what you did (i.e. What are the controls? Why this design?)

// Where I Started
For this web sockets assignment, I decided to create a chat room application that allows users to send messages to someone on both mobile and desktop. I began this process by researching methods as to how I was going to execute this application. Different sources of this research included watching YouTube videos, reading articles, and looking at example code from Socket.io. Once I developed a plan, I then used the folder from Lesson 7 on Web Sockets for a starting point. 

// What are the Controls?
When the user opens the application, they will be introduced with a prompt that will ask them to enter in the name of their choosing to represent themselves. Once they press enter, the chat room will open and there will be a message indicating that they have joined the chat. Then, the user has an input text bar at the bottom of the screen where they can use their keyboard to type in their message, press send, and it will show up on the screen. 

When the second user joins in, the first user will be notified that someone has joined the chat. When the first user sends a message, it will pop up on the second user's screen. This concept will go back and forth between the users until they stop.

What was Challenging?
The most challenging part of this assignment was getting the chat function to work properly. I ran into an issue where the text would not show up or it would only show up for one user and not the other, which would defeat the purpose of having a chat room application. There were instances where I had to keep redoing certain points of the javascript code, and when I ran into issues, this brought me to going back to reviewing other resources to trouble shoot.

What Went Well (i.e. How did you solve the above challenges?)
To solve the above challenge, I was able to use example code as a reference from Socket.io to go over and repair the areas that I went wrong in. This took me a few hours to a 2 days to complete and once that was over, I was able to focus on the CSS portion of the application. In the end, I was happy with the result of my chat room.

URL to Github Repository:


