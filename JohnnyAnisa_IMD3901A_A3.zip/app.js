const express   = require('express');
const app       = express();
const http      = require('http');
const server    = http.createServer(app);
const io        = require('socket.io')(server); //our websockets library
const users = {};

const LISTEN_PORT = 8080;

//our routes
app.get('/', function(req, res) {
    res.sendFile('index.html', {root:__dirname + '/public/'});
});

//socket.io events
io.on('connection', (socket) => {

    // user
    socket.on('new-user', userName => {
        users[socket.id] = userName;
        socket.broadcast.emit('user-connected', userName);
    })
    // disconnects 
    socket.on('disconnect', () => {
        io.emit('message', 'A user has left the chat');
    });

    // listen for message
    socket.on('send-chatmessage', chatMsg => {
        socket.broadcast.emit('message', { chatMsg: chatMsg, userName: users[socket.id] });
    })

});

app.use(express.static(__dirname + '/public'));
server.listen(LISTEN_PORT);
console.log('Listening to port: ' + LISTEN_PORT);